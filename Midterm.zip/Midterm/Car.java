/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package midterm;

/**
 *
 * @author Michael
 */
//child class of Vehicle
public class Car extends Vehicle{
        private int numDoors;
        //constructor
        public Car(String brand, int year, int numDoors) {
            super(brand, year);
            this.numDoors = numDoors;
        }
        
        @Override
        public void startEngine(){
            System.out.println("Car engine started.");
        }
    }
