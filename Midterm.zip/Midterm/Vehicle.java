/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package midterm;

/**
 *
 * @author Michael
 */
//parent class of Car
public class Vehicle {
    private String brand;
    private int year;
        //constructor
        public  Vehicle(String brand, int year) {
            this.brand = brand;
            this.year = year;
        }
        
        public void startEngine(){
           System.out.println("Engine started.");
        }
      
       
       
       
}
