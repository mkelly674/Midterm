/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package midterm;

/**
 *
 * @author Michael
 */

public class Midterm{
    

    public static void main(String[] args) {
       //Creating a rectangle and calculating the area.
       Rectangle rectangle = new Rectangle(67.0, 32.2);
       double area = rectangle.calculateArea();
       System.out.println("The area of this rectangle is:" + area);
       //explaining encapsulation and how it is implemented
       
       /*
       Encapsulation is combining varibles with methods active onto the
       varibles into one single entity. It allows for more control on the
       classes with both visibility and access.
       */
       
       //creating vehicle from Vehicle class
       Vehicle vehicle = new Vehicle("Train", 2012);
       vehicle.startEngine();
       //creating car
       Car car = new Car("BMW", 2023, 4);
       car.startEngine();
       
       //handling mathmatics with exception handling
       int x = 3;
       int y = 0;
       
       //using a try and catch
       try{
           int z = x/y;
           System.out.println("The result is: " + z);
       } catch (ArithmeticException e) {
           System.out.println("Error caused by division by zero");
       }
       //explain the purpose of the try, catch and finally blocks
       
       /*
       The try block contains the possible eception that you might throw.
       The catch block contains the execution if an exception was thrown in the
       try block.
       The finally block runs code that will execute regardless of if an
       exception was thrown.
       */
       
       // Using the throw method
       x = 6;
       y = 2;
       //trying something that is divisible
       try {
           int z = y/x;
           //using if to catch undesirable outcome to throw exception
           if (z == 0)
               throw new ArithmeticException();
       } catch(ArithmeticException e) {
           System.out.println(x/y);
       }
       //Creating the GUI
    new myFrame();
    //Explaining the role of the EDT in Swing applications
    /*
    EDT manages the event order to reduce the risks of thread interference
    or memory consistency errors. This is important because Swing object
    methods are not "thread safe".
    */
    }
   
}
