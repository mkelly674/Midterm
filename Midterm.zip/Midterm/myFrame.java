/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package midterm;

/**
 *
 * @author Michael
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
public class myFrame extends JFrame implements ActionListener{
    JButton button;
    JLabel label;
    myFrame(){
        
        //creating label
        ImageIcon icon = new ImageIcon("TrigIdentities.png");
        label = new JLabel();
        label.setIcon(icon);
        label.setBounds(50,100,50,50);
        label.setVisible(false);
        
        //setting button
        button = new JButton();
        button.setBounds(200,100,100,50);
        button.addActionListener(this);
        button.setText("Clicking the button");
        
        //setting the JFrame
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(null);
        this.setSize(400,400);
        this.setVisible(true);
        this.add(button);
        this.add(label);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
     if(e.getSource()==button){
            System.out.println("Clicked the button");
            label.setVisible(true);
    }    
    }
    
}
